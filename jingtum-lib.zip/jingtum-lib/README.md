# About Jingtum lib

Basic js lib to be used for interacting with jingtum blockchain network.
- Keep only one websocket connecttion to jingtum and handle exception
- Do transaction to jingtumd, and process response
- Subscribe events, include server, ledger, account and so on
- Get other information from jingtum

## INSTALL
```
$ npm install jingtum-lib
```

## Documents

For more information see `docs.md`
