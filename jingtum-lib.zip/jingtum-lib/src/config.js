/**
 * Created by yalei on 2017/4/25.
 */
var config = {
    currency: 'SWT',
    ACCOUNT_ZERO: 'jjjjjjjjjjjjjjjjjjjjjhoLvTp',
    ACCOUNT_ONE : 'jjjjjjjjjjjjjjjjjjjjBZbvri',
    fee: 10000
};

module.exports = config;