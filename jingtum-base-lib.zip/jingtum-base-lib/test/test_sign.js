var keypairs = require('../src/keypairs');

var pair = keypairs.deriveKeyPair('sndvZyXtTHV7BDFNswdg1tGsZ11i6');
console.log(pair);
